# AWS-IoT-RESTful
Open-source LabVIEW project for Amazon's IoT Pub/Sub platform implemented using REST api.
